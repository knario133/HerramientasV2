﻿using EnvDTE;
using Microsoft.CodeAnalysis;
using Microsoft.VisualStudio.LanguageServices;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.Build.Locator;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.MSBuild;
using System.Globalization;
using System.Security.Cryptography;
using System;
using System.Reflection;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.Text;
using Microsoft.VisualStudio.Text.Editor;
using Microsoft.VisualStudio.TextManager.Interop;
using Microsoft.VisualStudio.Editor;
using Microsoft.VisualStudio.Shell;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.Debugger.Interop;
using System.Xml.Linq;

namespace HerramientasV2
{
    public partial class ObtieneUltimaCDNWindowControl : UserControl
    {
        public class MyItem
        {
            public string Name { get; set; }
            public string Value { get; set; }
            public bool IsSelected { get; set; }
        }

        public ObtieneUltimaCDNWindowControl()
        {
            InitializeComponent();
            List<MyItem> items = new List<MyItem>
        {
            new MyItem { Name = "JS jQuery -", Value = "jquery" },
         //   new MyItem { Name = "CSS Bootstrap -", Value = "bootstrap" },
            new MyItem { Name = "JS Bootstrap Bundle -", Value = "bootstrap" },
         //   new MyItem { Name = "JS Popper.js -", Value = "@popperjs/core" },
         //   new MyItem { Name = "JS Bootstrap -", Value = "bootstrap" },
            new MyItem { Name = "Boostrap -", Value = "bootstrap" },
            new MyItem { Name = "JS SweetAlert2 -", Value = "sweetalert2" },
            new MyItem { Name = "JS jQuery UI -", Value = "jquery-ui" },
            new MyItem { Name = "JS DataTables -", Value = "datatables.net" },
            new MyItem { Name = "JS DataTables Buttons -", Value = "datatables.net-buttons" },
            new MyItem { Name = "JS DataTables Select -", Value = "datatables.net-select" }
        };
            ListaReferencias.ItemsSource = items;
        }

        private async void button1_Click(object sender, RoutedEventArgs e)
        {
            // Obtén las bibliotecas seleccionadas
            var selectedLibraries = ListaReferencias.Items
    .Cast<MyItem>()
    .Where(item => item.IsSelected)
    .ToList();

            if (selectedLibraries.Count == 0)
            {
                VS.MessageBox.Show("CdnWindowControl", "No se seleccionó ninguna biblioteca");
                return;
            }

            // Obtén las últimas versiones y URLs de las bibliotecas seleccionadas
            List<string> libraryUrls = await GetLatestLibraryUrls(selectedLibraries);

            // Descarga las bibliotecas y crea una carpeta "Librerias" en el proyecto activo
            await DownloadLibrariesAndCreateFolder(libraryUrls);

            VS.MessageBox.Show("CdnWindowControl", "Bibliotecas descargadas e incluidas en el proyecto");

        }

        protected async Task DownloadLibrariesAndCreateFolder(List<string> libraryUrls)
        {
            // Obtener la carpeta "Librerias" en el proyecto activo
            Community.VisualStudio.Toolkit.Project activeProject = await VS.Solutions.GetActiveProjectAsync();
            string folderPath = Path.Combine(Path.GetDirectoryName(activeProject.FullPath) + "\\", "Librerias");

            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            // Descargar cada archivo de la lista
            using (HttpClient client = new HttpClient())
            {
                foreach (string libraryUrl in libraryUrls)
                {
                    string fileName = Path.GetFileName(libraryUrl);
                    string filePath = Path.Combine(folderPath, fileName);

                    // Verificar si el archivo ya existe y eliminarlo si es necesario
                    if (File.Exists(filePath))
                    {
                        File.Delete(filePath);
                    }

                    // Descargar el archivo y guardarlo en la carpeta "Librerias"
                    HttpResponseMessage response = await client.GetAsync(libraryUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        byte[] fileBytes = await response.Content.ReadAsByteArrayAsync();
                        File.WriteAllBytes(filePath, fileBytes);
                        await activeProject.AddExistingFilesAsync(filePath);
                        //   SolutionItem?[] ArchivosProyectoActual = activeProject.Result.Children.ToArray();

                        // EnvDTE.ProjectItems projectItems = activeProject.ProjectItems.Item("Librerias").ProjectItems;
                    }
                    else
                    {
                        Console.WriteLine($"Error downloading {libraryUrl}: {response.StatusCode}");
                    }
                }
            }
           
        }
        public static async Task<string> ObtieneCodigoUltimaVersion(string value)
        {
            if (value.Contains("datatables"))
            {
                string baseUrl = "https://api.datatables.net/versions/feed";  // Cambiado a la API de versiones de DataTables
                using HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(baseUrl);
                string content = await response.Content.ReadAsStringAsync();
                JObject json = JObject.Parse(content);
                string latestVersion;
                if (value.Contains("buttons"))
                {
                    latestVersion = json["Buttons"]["release"]["version"].ToString();
                }
                else
                {
                    if (value.Contains("select"))
                    {
                        latestVersion = json["Select"]["release"]["version"].ToString();
                    }
                    else
                    {
                        latestVersion = json["DataTables"]["release"]["version"].ToString();  // Ruta modificada para acceder a la versión de lanzamiento
                    }
                }
                return latestVersion;
            }
            else
            {
                string baseUrl = "https://data.jsdelivr.com/v1/package/npm/";
                using HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(baseUrl + value);
                string content = await response.Content.ReadAsStringAsync();
                JObject json = JObject.Parse(content);
                string latestVersion = json["tags"]["latest"].ToString();
                return latestVersion;
            }
        }
        public static async Task<List<string>> GetLatestLibraryUrls(List<MyItem> selectedLibraries)
        {
            List<string> Resultado = new List<string>();
            string baseUrl = "https://data.jsdelivr.com/v1/package/npm/";
            using HttpClient client = new HttpClient();
            foreach (MyItem library in selectedLibraries)
            {
                string libraryUrl;
                HttpResponseMessage response = await client.GetAsync(baseUrl + library.Value);
                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();
                    JObject json = JObject.Parse(content);
                    string latestVersion = json["tags"]["latest"].ToString();
                    switch (library.Name)
                    {
                        case "JS SweetAlert2 -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/sweetalert2.all.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/sweetalert2.min.css";
                            break;
                        case "JS jQuery -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/jquery.min.js";
                            break;
                        //case "CSS Bootstrap -":
                        //    libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/css/{library.Value}.min.css";
                        //    break;
                        case "JS Bootstrap Bundle -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"bootstrap"}@{await ObtieneCodigoUltimaVersion("bootstrap")}/dist/css/{library.Value}.min.css";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/js/{library.Value}.bundle.min.js";
                            break;
                        //case "JS Popper.js -":
                        //    libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/umd/popper.min.js";
                        //    break;
                        //case "JS Bootstrap -":
                        //    libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/js/{library.Value}.min.js";
                        //    break;
                        case "Boostrap -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"bootstrap"}@{await ObtieneCodigoUltimaVersion("bootstrap")}/dist/css/{library.Value}.min.css";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"@popperjs/core"}@{await ObtieneCodigoUltimaVersion("@popperjs/core")}/dist/umd/popper.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"bootstrap"}@{await ObtieneCodigoUltimaVersion("bootstrap")}/dist/js/{library.Value}.min.js";                          
                            break;
                        case "JS jQuery UI -":
                            //libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/jquery-ui.min.js";
                            //break;
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"jquery"}@{await ObtieneCodigoUltimaVersion("jquery")}/dist/jquery.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/jquery-ui.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/themes/base/theme.min.css";
                            Resultado.Add(libraryUrl);
                            break;
                        case "JS DataTables -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"jquery"}@{await ObtieneCodigoUltimaVersion("jquery")}/dist/jquery.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/{await ObtieneCodigoUltimaVersion("datatables.net")}/js/jquery.dataTables.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/{await ObtieneCodigoUltimaVersion("datatables.net")}/css/jquery.dataTables.min.css";
                            Resultado.Add(libraryUrl);
                            break;
                        case "JS DataTables Buttons -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"jquery"}@{await ObtieneCodigoUltimaVersion("jquery")}/dist/jquery.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/{await ObtieneCodigoUltimaVersion("datatables.net")}/js/jquery.dataTables.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/{await ObtieneCodigoUltimaVersion("datatables.net")}/css/jquery.dataTables.min.css";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/buttons/{await ObtieneCodigoUltimaVersion("datatables.net-buttons")}/js/dataTables.buttons.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/buttons/{await ObtieneCodigoUltimaVersion("datatables.net-buttons")}/css/buttons.dataTables.min.css";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/buttons/{await ObtieneCodigoUltimaVersion("datatables.net-buttons")}/js/buttons.html5.min.js";
                            Resultado.Add(libraryUrl);
                            break;
                        case "JS DataTables Select -":
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{"jquery"}@{await ObtieneCodigoUltimaVersion("jquery")}/dist/jquery.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/{await ObtieneCodigoUltimaVersion("datatables.net")}/js/jquery.dataTables.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/{await ObtieneCodigoUltimaVersion("datatables.net")}/css/jquery.dataTables.min.css";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/select/{await ObtieneCodigoUltimaVersion("datatables.net-select")}/js/dataTables.select.min.js";
                            Resultado.Add(libraryUrl);
                            libraryUrl = $"https://cdn.datatables.net/select/{await ObtieneCodigoUltimaVersion("datatables.net-select")}/css/select.dataTables.min.css";
                            Resultado.Add(libraryUrl);
                            break;
                        default:
                            libraryUrl = $"https://cdn.jsdelivr.net/npm/{library.Value}@{latestVersion}/dist/{library.Value}.min.js";
                            break;
                    }

                    Resultado.Add(libraryUrl);
                }
                else
                {
                    Console.WriteLine($"Error fetching {library.Name}: {response.StatusCode}");
                }
            }
            Resultado = Resultado.Distinct().ToList();
            return Resultado;
        }
    }
}
