﻿using System.Windows;
using System.Windows.Controls;

namespace HerramientasV2
{
    public partial class FormularioGeneraServicioRestControl : UserControl
    {
        public FormularioGeneraServicioRestControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            VS.MessageBox.Show("FormularioGeneraServicioRestControl", "Button clicked");
        }
    }
}
